import 'package:flutter/material.dart';
import 'common.dart';
import 'db.dart';
import 'receipt_screen.dart';

class DeliveryListScreen extends StatefulWidget {
  const DeliveryListScreen({super.key});
  @override
  State<DeliveryListScreen> createState() => _DeliveryListScreenState();
}

class _DeliveryListScreenState extends State<DeliveryListScreen> {
  final search = TextEditingController();
  List<Rec> rows = [];
  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { search.dispose(); super.dispose(); }
  Future<void> load() async {
    rows = await AppDb.instance.tokens(search: search.text, filter: 'pending');
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('آٹا حوالگی (زیر التوا ٹوکن)')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: TextField(
        controller: search, onChanged: (_) => load(),
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search),
            labelText: 'ٹوکن نمبر، نام یا موبائل', border: OutlineInputBorder()),
      )),
      Expanded(child: rows.isEmpty
          ? const Center(child: Text('کوئی زیر التوا ٹوکن نہیں'))
          : ListView.builder(
              itemCount: rows.length,
              itemBuilder: (_, i) {
                final r = rows[i];
                final bal = dbl(r['total']) - dbl(r['paid']);
                return Card(child: ListTile(
                  title: Text('ٹوکن #${r['token_no']} — ${r['customer_name']}'),
                  subtitle: Text('${r['product_name']} • خالص ${money.format(dbl(r['net_wheat_kg']))} کلو • بقایا ${money.format(bal)}\n${fmtDate(r['created_at'])}'),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () async {
                    await Navigator.push(context, MaterialPageRoute(
                        builder: (_) => DeliverScreen(id: r['id'] as int)));
                    load();
                  },
                ));
              })),
    ]),
  );
}

class DeliverScreen extends StatefulWidget {
  final int id;
  const DeliverScreen({super.key, required this.id});
  @override
  State<DeliverScreen> createState() => _DeliverScreenState();
}

class _DeliverScreenState extends State<DeliverScreen> {
  Rec? t;
  List<Rec> items = [];
  final flour = <int, TextEditingController>{};
  final pay = TextEditingController();
  bool busy = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final r = await AppDb.instance.tokenById(widget.id);
    final it = await AppDb.instance.itemsOf(widget.id);
    if (r == null || !mounted) return;
    for (final x in it) {
      flour[x['id'] as int] = TextEditingController(text: dbl(x['net_kg']).toStringAsFixed(2));
    }
    pay.text = (dbl(r['total']) - dbl(r['paid'])).toStringAsFixed(2);
    setState(() { t = r; items = it; });
  }

  @override
  void dispose() {
    for (final c in flour.values) { c.dispose(); }
    pay.dispose();
    super.dispose();
  }

  Future<void> done() async {
    final r = t!;
    final bal = dbl(r['total']) - dbl(r['paid']);
    final p = numOf(pay);
    for (final c in flour.values) {
      if (numOf(c) <= 0) { snack(context, 'ہر آئٹم کے واپس دیے گئے آٹے کا وزن درج کریں'); return; }
    }
    if (p > bal + 0.009) { snack(context, 'رقم بقایا سے زیادہ ہے'); return; }
    if (bal - p > 0.009) {
      final ok = await confirm(context, 'ادھار',
          '${money.format(bal - p)} روپے بقایا رہ جائے گا۔ حوالگی مکمل کریں؟');
      if (!ok) return;
    }
    setState(() => busy = true);
    await AppDb.instance.deliver(
        widget.id, flour.map((k, v) => MapEntry(k, numOf(v))), p);
    if (!mounted) return;
    await Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => ReceiptScreen(id: widget.id)));
  }

  @override
  Widget build(BuildContext context) {
    final r = t;
    if (r == null) {
      return Scaffold(appBar: AppBar(title: const Text('آٹا حوالگی')),
          body: const Center(child: CircularProgressIndicator()));
    }
    final bal = dbl(r['total']) - dbl(r['paid']);
    return Scaffold(
      appBar: AppBar(title: Text('ٹوکن #${r['token_no']} کی حوالگی')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
          statRow('گاہک', '${r['customer_name']}', bold: true),
          if ('${r['phone']}'.isNotEmpty) statRow('موبائل', '${r['phone']}'),
          statRow('تاریخ', fmtDate(r['created_at'])),
          const Divider(),
          for (final x in items)
            statRow('${x['grain_name']}', 'خالص ${money.format(dbl(x['net_kg']))} کلو'),
          statRow('کل خالص وزن', '${money.format(dbl(r['net_wheat_kg']))} کلو', bold: true),
          const Divider(),
          statRow('کل رقم', '${money.format(dbl(r['total']))} روپے'),
          statRow('پہلے وصول', '${money.format(dbl(r['paid']))} روپے'),
          statRow('بقایا', '${money.format(bal)} روپے', bold: true,
              color: bal > 0.009 ? Colors.red.shade700 : null),
        ]))),
        const SizedBox(height: 12),
        for (final x in items)
          field(flour[x['id'] as int]!, 'واپس دیا گیا آٹا - ${x['grain_name']} (کلو) *', numeric: true),
        field(pay, 'اب وصول کی جانے والی رقم', numeric: true),
        FilledButton.icon(
          onPressed: busy ? null : done,
          icon: const Icon(Icons.check_circle),
          label: const Text('حوالگی مکمل کریں'),
        ),
      ]),
    );
  }
}
