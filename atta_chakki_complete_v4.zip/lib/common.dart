import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'db.dart';

final money = NumberFormat('#,##0.00', 'en_US');
final dateFmt = DateFormat('dd-MM-yyyy hh:mm a');
final dayFmt = DateFormat('dd-MM-yyyy');

String fmtDate(Object? iso) {
  final d = DateTime.tryParse('${iso ?? ''}');
  return d == null ? '' : dateFmt.format(d);
}

double numOf(TextEditingController c) => double.tryParse(c.text.trim()) ?? 0;

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

String methodUrdu(Object? m) => m == 'per_maund' ? 'فی من' : 'فی کلو';

String rateText(double r) => r == r.roundToDouble() ? r.toInt().toString() : r.toString();

String statusUrdu(String s) {
  switch (s) {
    case 'Pending': return 'زیر التوا';
    case 'Delivered': return 'حوالگی مکمل';
    case 'Completed': return 'مکمل';
    case 'Cancelled': return 'منسوخ';
  }
  return s;
}

Color statusColor(String s) {
  switch (s) {
    case 'Pending': return Colors.orange.shade800;
    case 'Cancelled': return Colors.red.shade700;
    default: return Colors.green.shade800;
  }
}

Widget field(TextEditingController controller, String label,
        {bool numeric = false, ValueChanged<String>? changed, TextInputType? type}) =>
    Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: controller,
        keyboardType: type ??
            (numeric ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text),
        inputFormatters: numeric ? [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))] : null,
        onChanged: changed,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );

Future<bool> confirm(BuildContext context, String title, String msg) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('نہیں')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('جی ہاں')),
      ],
    ),
  );
  return r ?? false;
}

Future<double?> askAmount(BuildContext context, String title, double max) {
  final c = TextEditingController(text: max.toStringAsFixed(2));
  String? err;
  return showDialog<double>(
    context: context,
    builder: (_) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: Text(title),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('زیادہ سے زیادہ: ${money.format(max)} روپے'),
          const SizedBox(height: 8),
          TextField(
            controller: c, autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
            decoration: InputDecoration(errorText: err, border: const OutlineInputBorder(), labelText: 'رقم'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('منسوخ')),
          FilledButton(
            onPressed: () {
              final v = double.tryParse(c.text.trim()) ?? 0;
              if (v <= 0 || v > max + 0.009) {
                setS(() => err = 'درست رقم درج کریں');
                return;
              }
              Navigator.pop(ctx, v);
            },
            child: const Text('وصول کریں'),
          ),
        ],
      ),
    ),
  );
}

Future<String?> askText(BuildContext context, String title, String label) {
  final c = TextEditingController();
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, autofocus: true,
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('واپس')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('منسوخ کریں')),
      ],
    ),
  );
}

class CustomerPicker extends StatefulWidget {
  final TextEditingController name;
  final TextEditingController phone;
  final String label;
  const CustomerPicker({super.key, required this.name, required this.phone, this.label = 'گاہک کا نام *'});
  @override
  State<CustomerPicker> createState() => _CustomerPickerState();
}

class _CustomerPickerState extends State<CustomerPicker> {
  final focus = FocusNode();
  List<Rec> customers = [];
  @override
  void initState() {
    super.initState();
    AppDb.instance.customerList().then((r) { if (mounted) setState(() => customers = r); });
  }
  @override
  void dispose() { focus.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: RawAutocomplete<Rec>(
      textEditingController: widget.name,
      focusNode: focus,
      displayStringForOption: (c) => '${c['name']}',
      optionsBuilder: (v) {
        final q = v.text.trim();
        if (q.isEmpty) return const Iterable<Rec>.empty();
        return customers.where((c) => '${c['name']}'.contains(q) || '${c['phone']}'.contains(q)).take(6);
      },
      onSelected: (c) => widget.phone.text = '${c['phone']}',
      fieldViewBuilder: (ctx, ctrl, fn, onSubmit) => TextField(
        controller: ctrl, focusNode: fn,
        decoration: InputDecoration(labelText: widget.label, border: const OutlineInputBorder()),
      ),
      optionsViewBuilder: (ctx, onSel, options) => Align(
        alignment: AlignmentDirectional.topStart,
        child: Material(
          elevation: 4,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 220, maxWidth: 320),
            child: ListView(
              padding: EdgeInsets.zero, shrinkWrap: true,
              children: options.map((o) => ListTile(
                title: Text('${o['name']}'),
                subtitle: Text('${o['phone']}'),
                onTap: () => onSel(o),
              )).toList(),
            ),
          ),
        ),
      ),
    ),
  );
}

Widget statRow(String label, String value, {bool bold = false, Color? color}) => Padding(
  padding: const EdgeInsets.symmetric(vertical: 3),
  child: Row(children: [
    Expanded(child: Text(label)),
    Text(value, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, color: color)),
  ]),
);
