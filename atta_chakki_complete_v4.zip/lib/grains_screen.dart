import 'package:flutter/material.dart';
import 'common.dart';
import 'db.dart';

class GrainsScreen extends StatefulWidget {
  const GrainsScreen({super.key});
  @override
  State<GrainsScreen> createState() => _GrainsScreenState();
}

class _GrainsScreenState extends State<GrainsScreen> {
  List<Rec> rows = [];
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    rows = await AppDb.instance.grains();
    if (mounted) setState(() {});
  }

  Future<void> edit(Rec? g) async {
    final name = TextEditingController(text: g == null ? '' : '${g['name']}');
    final rate = TextEditingController(text: g == null ? '' : rateText(dbl(g['rate'])));
    var method = g == null ? 'per_kg' : '${g['method']}';
    String? err;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(g == null ? 'نیا اناج' : 'اناج میں تبدیلی'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name,
                decoration: const InputDecoration(labelText: 'اناج کا نام', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            TextField(
              controller: rate,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'پسائی ریٹ (روپے)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: method,
              decoration: const InputDecoration(labelText: 'ریٹ کا طریقہ', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'per_kg', child: Text('فی کلو')),
                DropdownMenuItem(value: 'per_maund', child: Text('فی من (40 کلو)')),
              ],
              onChanged: (v) => setS(() => method = v ?? 'per_kg'),
            ),
            if (err != null) Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(err!, style: TextStyle(color: Colors.red.shade700)),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
            FilledButton(
              onPressed: () {
                if (name.text.trim().isEmpty || (double.tryParse(rate.text.trim()) ?? -1) < 0) {
                  setS(() => err = 'نام اور درست ریٹ درج کریں');
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: const Text('محفوظ کریں'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await AppDb.instance.saveGrain(
        id: g == null ? null : g['id'] as int,
        name: name.text.trim(),
        rate: double.parse(rate.text.trim()),
        method: method,
      );
    } catch (_) {
      if (mounted) snack(context, 'یہ نام پہلے سے موجود ہے');
    }
    load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('اناج اور ریٹ')),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () => edit(null),
      icon: const Icon(Icons.add),
      label: const Text('نیا اناج'),
    ),
    body: ListView.builder(
      padding: const EdgeInsets.only(bottom: 90),
      itemCount: rows.length,
      itemBuilder: (_, i) {
        final g = rows[i];
        final active = g['active'] == 1;
        return Card(child: ListTile(
          title: Text('${g['name']}'),
          subtitle: Text('${rateText(dbl(g['rate']))} روپے ${methodUrdu(g['method'])}'),
          onTap: () => edit(g),
          trailing: Switch(
            value: active,
            onChanged: (v) async {
              await AppDb.instance.setGrainActive(g['id'] as int, v);
              load();
            },
          ),
        ));
      },
    ),
  );
}
