import 'package:flutter/material.dart';
import 'common.dart';
import 'db.dart';
import 'receipt_screen.dart';

class _Line {
  String grain;
  String method;
  String dedMode = 'kg';
  final gross = TextEditingController();
  final ded = TextEditingController(text: '0');
  final why = TextEditingController();
  final rate = TextEditingController();
  _Line(this.grain, this.method, double r) { rate.text = rateText(r); }

  double get g => numOf(gross);
  double get dk => dedMode == 'percent' ? g * numOf(ded) / 100 : numOf(ded);
  double get net => (g - dk).clamp(0, g).toDouble();
  double get charge => method == 'per_maund' ? (net / 40) * numOf(rate) : net * numOf(rate);
  void dispose() { gross.dispose(); ded.dispose(); why.dispose(); rate.dispose(); }
}

class NewTokenScreen extends StatefulWidget {
  const NewTokenScreen({super.key});
  @override
  State<NewTokenScreen> createState() => _NewTokenScreenState();
}

class _NewTokenScreenState extends State<NewTokenScreen> {
  final nm = TextEditingController();
  final ph = TextEditingController();
  final paid = TextEditingController(text: '0');
  final notes = TextEditingController();
  List<Rec> grains = [];
  final lines = <_Line>[];
  bool loading = false;
  bool loaded = false;

  double get total => lines.fold<double>(0, (s, l) => s + l.charge);
  double get totalNet => lines.fold<double>(0, (s, l) => s + l.net);

  @override
  void initState() {
    super.initState();
    AppDb.instance.grains(activeOnly: true).then((g) {
      grains = g;
      if (g.isNotEmpty) addLine();
      if (mounted) setState(() => loaded = true);
    });
  }

  @override
  void dispose() {
    for (final c in [nm, ph, paid, notes]) { c.dispose(); }
    for (final l in lines) { l.dispose(); }
    super.dispose();
  }

  void addLine() {
    final g = grains.first;
    lines.add(_Line('${g['name']}', '${g['method']}', dbl(g['rate'])));
  }

  void pickGrain(_Line l, String name) {
    final g = grains.firstWhere((x) => x['name'] == name);
    l.grain = name;
    l.method = '${g['method']}';
    l.rate.text = rateText(dbl(g['rate']));
  }

  Future<void> save() async {
    if (nm.text.trim().isEmpty) { snack(context, 'گاہک کا نام درج کریں'); return; }
    for (final l in lines) {
      if (l.g <= 0) { snack(context, 'ہر آئٹم کا وزن درج کریں'); return; }
      if (l.dk > l.g) { snack(context, 'کٹوتی اصل وزن سے زیادہ نہیں ہو سکتی'); return; }
    }
    if (numOf(paid) > total + 0.009) { snack(context, 'وصول شدہ رقم کل رقم سے زیادہ ہے'); return; }
    setState(() => loading = true);
    final items = lines.map<Rec>((l) => {
      'grain_name': l.grain, 'gross_kg': l.g, 'deduction_kg': l.dk,
      'deduction_percent': l.dedMode == 'percent' ? numOf(l.ded) : 0,
      'deduction_details': l.why.text.trim(), 'net_kg': l.net,
      'rate': numOf(l.rate), 'method': l.method, 'charges': l.charge,
    }).toList();
    final id = await AppDb.instance.saveToken({
      'customer_name': nm.text.trim(), 'phone': ph.text.trim(),
      'created_at': DateTime.now().toIso8601String(), 'business_type': 'Grinding',
      'product_name': lines.map((l) => l.grain).toSet().join(' + '),
      'wheat_kg': lines.fold<double>(0, (s, l) => s + l.g),
      'deduction_kg': lines.fold<double>(0, (s, l) => s + l.dk),
      'net_wheat_kg': totalNet, 'charges': total, 'total': total,
      'paid': numOf(paid), 'status': 'Pending', 'notes': notes.text.trim(),
    }, items: items);
    if (!mounted) return;
    await Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ReceiptScreen(id: id)));
  }

  Widget lineCard(int i, _Line l) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        Row(children: [
          Text('آئٹم ${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold)),
          const Spacer(),
          if (lines.length > 1)
            IconButton(
              icon: Icon(Icons.delete_outline, color: Colors.red.shade700),
              onPressed: () => setState(() { lines.removeAt(i).dispose(); }),
            ),
        ]),
        DropdownButtonFormField<String>(
          value: l.grain,
          decoration: const InputDecoration(labelText: 'اناج', border: OutlineInputBorder()),
          items: grains.map((g) => DropdownMenuItem(
              value: '${g['name']}', child: Text('${g['name']}'))).toList(),
          onChanged: (v) => setState(() { if (v != null) pickGrain(l, v); }),
        ),
        const SizedBox(height: 10),
        field(l.gross, 'اصل وزن (کلو) *', numeric: true, changed: (_) => setState(() {})),
        Row(children: [
          Expanded(child: DropdownButtonFormField<String>(
            value: l.dedMode,
            decoration: const InputDecoration(labelText: 'کٹوتی', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'kg', child: Text('کلو')),
              DropdownMenuItem(value: 'percent', child: Text('فیصد')),
            ],
            onChanged: (v) => setState(() => l.dedMode = v ?? 'kg'),
          )),
          const SizedBox(width: 8),
          Expanded(child: field(l.ded, 'مقدار', numeric: true, changed: (_) => setState(() {}))),
        ]),
        field(l.why, 'کٹوتی کی وجہ (مٹی، بھوسہ، نمی)'),
        Row(children: [
          Expanded(child: field(l.rate, 'ریٹ (روپے)', numeric: true, changed: (_) => setState(() {}))),
          const SizedBox(width: 8),
          Expanded(child: DropdownButtonFormField<String>(
            value: l.method,
            decoration: const InputDecoration(labelText: 'طریقہ', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'per_kg', child: Text('فی کلو')),
              DropdownMenuItem(value: 'per_maund', child: Text('فی من')),
            ],
            onChanged: (v) => setState(() => l.method = v ?? 'per_kg'),
          )),
        ]),
        const SizedBox(height: 10),
        statRow('خالص وزن', '${money.format(l.net)} کلو', bold: true),
        statRow('رقم', '${money.format(l.charge)} روپے', bold: true),
      ]),
    ),
  );

  @override
  Widget build(BuildContext context) {
    if (!loaded) {
      return Scaffold(appBar: AppBar(title: const Text('نیا ٹوکن / پسائی')),
          body: const Center(child: CircularProgressIndicator()));
    }
    if (grains.isEmpty) {
      return Scaffold(appBar: AppBar(title: const Text('نیا ٹوکن / پسائی')),
          body: const Center(child: Padding(padding: EdgeInsets.all(24),
              child: Text('پہلے سیٹنگ میں اناج اور ریٹ شامل کریں', textAlign: TextAlign.center))));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('نیا ٹوکن / پسائی')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        CustomerPicker(name: nm, phone: ph),
        field(ph, 'موبائل نمبر', type: TextInputType.phone),
        for (var i = 0; i < lines.length; i++) lineCard(i, lines[i]),
        OutlinedButton.icon(
          onPressed: () => setState(addLine),
          icon: const Icon(Icons.add),
          label: const Text('ایک اور اناج شامل کریں'),
        ),
        const SizedBox(height: 12),
        field(paid, 'وصول شدہ رقم (ایڈوانس)', numeric: true, changed: (_) => setState(() {})),
        field(notes, 'تفصیل / نوٹس'),
        Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(children: [
            statRow('کل خالص وزن', '${money.format(totalNet)} کلو'),
            statRow('کل پسائی', '${money.format(total)} روپے', bold: true),
            statRow('بقایا', '${money.format(total - numOf(paid))} روپے', bold: true),
          ]),
        )),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: loading ? null : save,
          icon: const Icon(Icons.save),
          label: Text(loading ? 'محفوظ ہو رہا ہے...' : 'محفوظ کریں اور رسید دکھائیں'),
        ),
      ]),
    );
  }
}

class NewSaleScreen extends StatefulWidget {
  const NewSaleScreen({super.key});
  @override
  State<NewSaleScreen> createState() => _NewSaleScreenState();
}

class _NewSaleScreenState extends State<NewSaleScreen> {
  final nm = TextEditingController();
  final ph = TextEditingController();
  final product = TextEditingController(text: 'آٹا');
  final qty = TextEditingController(text: '1');
  final rate = TextEditingController();
  final paid = TextEditingController();
  bool loading = false;
  double get total => numOf(qty) * numOf(rate);

  @override
  void dispose() {
    for (final c in [nm, ph, product, qty, rate, paid]) { c.dispose(); }
    super.dispose();
  }

  Future<void> save() async {
    if (total <= 0) { snack(context, 'مقدار اور ریٹ درج کریں'); return; }
    final name = nm.text.trim().isEmpty ? walkIn : nm.text.trim();
    final pd = paid.text.trim().isEmpty ? total : numOf(paid);
    if (pd > total + 0.009) { snack(context, 'وصول شدہ رقم کل رقم سے زیادہ ہے'); return; }
    if (pd < total - 0.009 && name == walkIn && ph.text.trim().isEmpty) {
      snack(context, 'ادھار کے لیے گاہک کا نام یا موبائل درج کریں');
      return;
    }
    setState(() => loading = true);
    final id = await AppDb.instance.saveToken({
      'customer_name': name, 'phone': ph.text.trim(),
      'created_at': DateTime.now().toIso8601String(), 'business_type': 'Sale',
      'product_name': product.text.trim(), 'sale_qty': numOf(qty), 'rate': numOf(rate),
      'total': total, 'paid': pd, 'status': 'Completed', 'notes': 'فروخت',
    });
    if (!mounted) return;
    await Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ReceiptScreen(id: id)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('آٹا / گندم کی فروخت')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      CustomerPicker(name: nm, phone: ph, label: 'گاہک کا نام (خالی = نقد گاہک)'),
      field(ph, 'موبائل نمبر', type: TextInputType.phone),
      field(product, 'آئٹم کا نام'),
      field(qty, 'مقدار / کلو', numeric: true, changed: (_) => setState(() {})),
      field(rate, 'فی یونٹ ریٹ', numeric: true, changed: (_) => setState(() {})),
      field(paid, 'وصول شدہ رقم (خالی = پوری رقم)', numeric: true, changed: (_) => setState(() {})),
      Card(child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          statRow('کل فروخت', '${money.format(total)} روپے', bold: true),
          statRow('بقایا', '${money.format(total - (paid.text.trim().isEmpty ? total : numOf(paid)))} روپے'),
        ]),
      )),
      const SizedBox(height: 8),
      FilledButton(onPressed: loading ? null : save, child: const Text('محفوظ کریں اور رسید دکھائیں')),
    ]),
  );
}
