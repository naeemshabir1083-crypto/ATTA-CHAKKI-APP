import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'common.dart';
import 'db.dart';
import 'grains_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final shop = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  bool ready = false;

  @override
  void initState() {
    super.initState();
    AppDb.instance.settings().then((s) {
      shop.text = '${s['shop_name']}';
      phone.text = '${s['phone']}';
      address.text = '${s['address']}';
      if (mounted) setState(() => ready = true);
    });
  }

  @override
  void dispose() {
    for (final c in [shop, phone, address]) { c.dispose(); }
    super.dispose();
  }

  Future<void> save() async {
    await AppDb.instance.updateSettings(
      shopName: shop.text.trim().isEmpty ? 'آٹا چکی' : shop.text.trim(),
      phone: phone.text.trim(), address: address.text.trim(),
    );
    if (mounted) { snack(context, 'سیٹنگ محفوظ ہو گئی'); Navigator.pop(context); }
  }

  Future<void> backup() async {
    try {
      final f = await AppDb.instance.backupFile();
      await Share.shareXFiles([XFile(f.path)], text: 'آٹا چکی بیک اپ');
    } catch (e) {
      if (mounted) snack(context, 'بیک اپ میں خرابی: $e');
    }
  }

  Future<void> restore() async {
    final ok = await confirm(context, 'ڈیٹا بحال کریں',
        'موجودہ تمام ڈیٹا بیک اپ والے ڈیٹا سے بدل جائے گا۔ جاری رکھیں؟');
    if (!ok) return;
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any);
      final path = r?.files.single.path;
      if (path == null) return;
      await AppDb.instance.restore(File(path).path);
      if (mounted) snack(context, 'ڈیٹا بحال ہو گیا۔ ایپ دوبارہ کھولیں۔');
    } catch (e) {
      if (mounted) snack(context, 'بحالی ناکام: درست بیک اپ فائل منتخب کریں');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('سیٹنگ')),
    body: !ready
        ? const Center(child: CircularProgressIndicator())
        : ListView(padding: const EdgeInsets.all(16), children: [
            field(shop, 'دکان کا نام'),
            field(phone, 'موبائل نمبر'),
            field(address, 'پتہ'),
            OutlinedButton.icon(
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const GrainsScreen())),
              icon: const Icon(Icons.grain),
              label: const Text('اناج اور ریٹ'),
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: save, child: const Text('سیٹنگ محفوظ کریں')),
            const Divider(height: 40),
            const Text('ڈیٹا بیک اپ', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text('ہفتے میں ایک بار بیک اپ بنا کر WhatsApp، Drive یا کسی اور جگہ محفوظ کریں۔ فون خراب ہونے پر ڈیٹا یہیں سے واپس آئے گا۔'),
            const SizedBox(height: 10),
            FilledButton.tonalIcon(onPressed: backup, icon: const Icon(Icons.upload), label: const Text('بیک اپ بنائیں اور شیئر کریں')),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: restore, icon: const Icon(Icons.download), label: const Text('بیک اپ سے بحال کریں')),
          ]),
  );
}
