import 'package:flutter/material.dart';
import 'common.dart';
import 'db.dart';

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});
  @override
  State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> {
  final desc = TextEditingController();
  final amt = TextEditingController();
  List<Rec> rows = [];

  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { desc.dispose(); amt.dispose(); super.dispose(); }

  Future<void> load() async {
    final now = DateTime.now();
    rows = await AppDb.instance.expenses(
        dayKey(now.subtract(const Duration(days: 60))), dayKey(now));
    if (mounted) setState(() {});
  }

  Future<void> add() async {
    if (desc.text.trim().isEmpty || numOf(amt) <= 0) {
      snack(context, 'تفصیل اور رقم درج کریں');
      return;
    }
    await AppDb.instance.addExpense(desc.text.trim(), numOf(amt), DateTime.now());
    desc.clear();
    amt.clear();
    FocusScope.of(context).unfocus();
    load();
  }

  @override
  Widget build(BuildContext context) {
    final today = dayKey(DateTime.now());
    final todayTotal = rows
        .where((r) => r['expense_date'] == today)
        .fold<double>(0, (s, r) => s + dbl(r['amount']));
    return Scaffold(
      appBar: AppBar(title: const Text('اخراجات')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: Column(children: [
          field(desc, 'خرچ کی تفصیل (بجلی، مزدوری، مرمت...)'),
          Row(children: [
            Expanded(child: field(amt, 'رقم', numeric: true)),
            const SizedBox(width: 8),
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: FilledButton(onPressed: add, child: const Text('شامل کریں')),
            ),
          ]),
          statRow('آج کا خرچ', '${money.format(todayTotal)} روپے', bold: true),
        ])),
        const Divider(height: 1),
        Expanded(child: rows.isEmpty
            ? const Center(child: Text('کوئی خرچ درج نہیں'))
            : ListView.builder(
                itemCount: rows.length,
                itemBuilder: (_, i) {
                  final r = rows[i];
                  return ListTile(
                    title: Text('${r['description']}'),
                    subtitle: Text('${r['expense_date']}'),
                    leading: Text(money.format(dbl(r['amount'])),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        if (await confirm(context, 'خرچ حذف کریں', '${r['description']} حذف کر دیں؟')) {
                          await AppDb.instance.deleteExpense(r['id'] as int);
                          load();
                        }
                      },
                    ),
                  );
                })),
      ]),
    );
  }
}
