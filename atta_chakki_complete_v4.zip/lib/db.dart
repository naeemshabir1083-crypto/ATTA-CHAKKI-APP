import 'dart:io';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

typedef Rec = Map<String, Object?>;

const walkIn = 'نقد گاہک';

double dbl(Object? v) => (v as num?)?.toDouble() ?? 0;
String dayKey(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();
  Database? _db;

  Future<String> dbPath() async => p.join(await getDatabasesPath(), 'atta_chakki.db');

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await openDatabase(await dbPath(), version: 1, onCreate: (db, v) async {
      await db.execute('''CREATE TABLE settings(
        id INTEGER PRIMARY KEY CHECK(id=1),
        shop_name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '', default_rate REAL NOT NULL DEFAULT 5,
        charge_method TEXT NOT NULL DEFAULT 'per_kg')''');
      await db.insert('settings', {
        'id': 1, 'shop_name': 'آٹا چکی', 'phone': '', 'address': '',
        'default_rate': 5.0, 'charge_method': 'per_kg'});
      await db.execute('''CREATE TABLE customers(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)''');
      await db.execute('''CREATE TABLE tokens(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token_no INTEGER NOT NULL,
        customer_id INTEGER, customer_name TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
        business_type TEXT NOT NULL,
        wheat_kg REAL NOT NULL DEFAULT 0, deduction_kg REAL NOT NULL DEFAULT 0,
        deduction_percent REAL NOT NULL DEFAULT 0, net_wheat_kg REAL NOT NULL DEFAULT 0,
        deduction_details TEXT NOT NULL DEFAULT '',
        flour_kg REAL NOT NULL DEFAULT 0, product_name TEXT NOT NULL DEFAULT '',
        sale_qty REAL NOT NULL DEFAULT 0, rate REAL NOT NULL DEFAULT 0,
        charges REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0,
        paid REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Pending',
        notes TEXT NOT NULL DEFAULT '', delivered_at TEXT,
        cancel_reason TEXT NOT NULL DEFAULT '',
        UNIQUE(business_type, token_no),
        FOREIGN KEY(customer_id) REFERENCES customers(id))''');
      await db.execute('''CREATE TABLE grains(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE,
        rate REAL NOT NULL DEFAULT 0, method TEXT NOT NULL DEFAULT 'per_kg',
        active INTEGER NOT NULL DEFAULT 1)''');
      for (final g in ['گندم', 'مکئی', 'چاول', 'چنا', 'باجرا']) {
        await db.insert('grains', {'name': g, 'rate': 5.0, 'method': 'per_kg', 'active': 1});
      }
      await db.execute('''CREATE TABLE token_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT, token_id INTEGER NOT NULL,
        grain_name TEXT NOT NULL, gross_kg REAL NOT NULL DEFAULT 0,
        deduction_kg REAL NOT NULL DEFAULT 0, deduction_percent REAL NOT NULL DEFAULT 0,
        deduction_details TEXT NOT NULL DEFAULT '', net_kg REAL NOT NULL DEFAULT 0,
        rate REAL NOT NULL DEFAULT 0, method TEXT NOT NULL DEFAULT 'per_kg',
        charges REAL NOT NULL DEFAULT 0, flour_kg REAL NOT NULL DEFAULT 0,
        FOREIGN KEY(token_id) REFERENCES tokens(id))''');
      await db.execute('''CREATE TABLE payments(
        id INTEGER PRIMARY KEY AUTOINCREMENT, token_id INTEGER NOT NULL,
        amount REAL NOT NULL, payment_date TEXT NOT NULL,
        method TEXT NOT NULL DEFAULT 'Cash',
        FOREIGN KEY(token_id) REFERENCES tokens(id))''');
      await db.execute('''CREATE TABLE expenses(
        id INTEGER PRIMARY KEY AUTOINCREMENT, expense_date TEXT NOT NULL,
        description TEXT NOT NULL, amount REAL NOT NULL)''');
    });
    return _db!;
  }

  Future<Rec> settings() async {
    final db = await database;
    return (await db.query('settings', where: 'id=1')).first;
  }

  Future<void> updateSettings({required String shopName, required String phone,
      required String address}) async {
    final db = await database;
    await db.update('settings', {
      'shop_name': shopName, 'phone': phone, 'address': address}, where: 'id=1');
  }

  Future<List<Rec>> grains({bool activeOnly = false}) async {
    final db = await database;
    return db.query('grains', where: activeOnly ? 'active=1' : null, orderBy: 'id');
  }

  Future<void> saveGrain({int? id, required String name, required double rate,
      required String method}) async {
    final db = await database;
    final v = {'name': name, 'rate': rate, 'method': method};
    if (id == null) {
      await db.insert('grains', {...v, 'active': 1});
    } else {
      await db.update('grains', v, where: 'id=?', whereArgs: [id]);
    }
  }

  Future<void> setGrainActive(int id, bool active) async {
    final db = await database;
    await db.update('grains', {'active': active ? 1 : 0}, where: 'id=?', whereArgs: [id]);
  }

  Future<List<Rec>> itemsOf(int tokenId) async {
    final db = await database;
    return db.query('token_items', where: 'token_id=?', whereArgs: [tokenId], orderBy: 'id');
  }

  Future<List<Rec>> grainReport(String from, String to) async {
    final db = await database;
    return db.rawQuery('''SELECT i.grain_name AS name, COUNT(DISTINCT i.token_id) AS cnt,
      SUM(i.gross_kg) AS gross, SUM(i.net_kg) AS net, SUM(i.charges) AS amt
      FROM token_items i JOIN tokens t ON t.id=i.token_id
      WHERE t.status!='Cancelled' AND substr(t.created_at,1,10) BETWEEN ? AND ?
      GROUP BY i.grain_name ORDER BY net DESC''', [from, to]);
  }

  Future<int?> _customerId(Transaction txn, String name, String phone) async {
    if (phone.isEmpty && name == walkIn) return null;
    final rows = phone.isNotEmpty
        ? await txn.query('customers', where: 'phone=?', whereArgs: [phone], limit: 1)
        : await txn.query('customers', where: 'name=? COLLATE NOCASE AND phone=\'\'', whereArgs: [name], limit: 1);
    if (rows.isNotEmpty) return rows.first['id'] as int;
    return txn.insert('customers', {
      'name': name, 'phone': phone, 'created_at': DateTime.now().toIso8601String()});
  }

  Future<List<Rec>> customerList() async {
    final db = await database;
    return db.query('customers', orderBy: 'name COLLATE NOCASE');
  }

  Future<int> saveToken(Rec values, {List<Rec> items = const []}) async {
    final db = await database;
    return db.transaction((txn) async {
      final next = Sqflite.firstIntValue(await txn.rawQuery(
              'SELECT COALESCE(MAX(token_no),0)+1 FROM tokens WHERE business_type=?',
              [values['business_type']])) ?? 1;
      final cid = await _customerId(txn, '${values['customer_name']}', '${values['phone']}');
      final id = await txn.insert('tokens', {...values, 'token_no': next, 'customer_id': cid});
      for (final it in items) {
        await txn.insert('token_items', {...it, 'token_id': id});
      }
      final paid = dbl(values['paid']);
      if (paid > 0) {
        await txn.insert('payments', {
          'token_id': id, 'amount': paid,
          'payment_date': DateTime.now().toIso8601String(), 'method': 'Cash'});
      }
      return id;
    });
  }

  Future<Rec?> tokenById(int id) async {
    final db = await database;
    final r = await db.query('tokens', where: 'id=?', whereArgs: [id]);
    return r.isEmpty ? null : r.first;
  }

  Future<List<Rec>> tokens({String? search, String filter = 'all', int? customerId}) async {
    final db = await database;
    final w = <String>[];
    final a = <Object?>[];
    if (search != null && search.trim().isNotEmpty) {
      final s = '%${search.trim()}%';
      w.add('(CAST(token_no AS TEXT) LIKE ? OR customer_name LIKE ? OR phone LIKE ?)');
      a.addAll([s, s, s]);
    }
    if (customerId != null) { w.add('customer_id=?'); a.add(customerId); }
    switch (filter) {
      case 'pending': w.add("business_type='Grinding' AND status='Pending'"); break;
      case 'delivered': w.add("status='Delivered'"); break;
      case 'unpaid': w.add("status!='Cancelled' AND total-paid>0.009"); break;
      case 'cancelled': w.add("status='Cancelled'"); break;
    }
    return db.query('tokens',
        where: w.isEmpty ? null : w.join(' AND '), whereArgs: a, orderBy: 'id DESC');
  }

  Future<List<Rec>> payments(int tokenId) async {
    final db = await database;
    return db.query('payments', where: 'token_id=?', whereArgs: [tokenId], orderBy: 'id');
  }

  Future<void> addPayment(int id, double amount) async {
    final db = await database;
    await db.transaction((txn) async {
      final t = (await txn.query('tokens', where: 'id=?', whereArgs: [id])).first;
      final bal = dbl(t['total']) - dbl(t['paid']);
      if (t['status'] == 'Cancelled' || amount <= 0 || amount > bal + 0.009) {
        throw Exception('invalid amount');
      }
      await txn.insert('payments', {
        'token_id': id, 'amount': amount,
        'payment_date': DateTime.now().toIso8601String(), 'method': 'Cash'});
      await txn.rawUpdate('UPDATE tokens SET paid=paid+? WHERE id=?', [amount, id]);
    });
  }

  Future<void> deliver(int id, Map<int, double> flourByItem, double pay) async {
    final db = await database;
    await db.transaction((txn) async {
      final t = (await txn.query('tokens', where: 'id=?', whereArgs: [id])).first;
      final bal = dbl(t['total']) - dbl(t['paid']);
      if (t['status'] != 'Pending' || pay < 0 || pay > bal + 0.009) {
        throw Exception('invalid');
      }
      if (pay > 0) {
        await txn.insert('payments', {
          'token_id': id, 'amount': pay,
          'payment_date': DateTime.now().toIso8601String(), 'method': 'Cash'});
      }
      var flourKg = 0.0;
      for (final e in flourByItem.entries) {
        await txn.update('token_items', {'flour_kg': e.value},
            where: 'id=? AND token_id=?', whereArgs: [e.key, id]);
        flourKg += e.value;
      }
      await txn.update('tokens', {
        'paid': dbl(t['paid']) + pay, 'flour_kg': flourKg, 'status': 'Delivered',
        'delivered_at': DateTime.now().toIso8601String()},
        where: 'id=?', whereArgs: [id]);
    });
  }

  Future<void> cancelToken(int id, String reason) async {
    final db = await database;
    await db.transaction((txn) async {
      final t = (await txn.query('tokens', where: 'id=?', whereArgs: [id])).first;
      final paid = dbl(t['paid']);
      if (paid > 0) {
        await txn.insert('payments', {
          'token_id': id, 'amount': -paid,
          'payment_date': DateTime.now().toIso8601String(), 'method': 'Refund'});
      }
      await txn.update('tokens', {
        'status': 'Cancelled', 'paid': 0, 'cancel_reason': reason},
        where: 'id=?', whereArgs: [id]);
    });
  }

  Future<List<Rec>> customersWithBalance({String? search}) async {
    final db = await database;
    final s = '%${(search ?? '').trim()}%';
    return db.rawQuery('''
      SELECT c.id, c.name, c.phone,
        COALESCE(SUM(CASE WHEN t.status!='Cancelled' THEN t.total-t.paid END),0) AS due,
        COUNT(t.id) AS cnt
      FROM customers c LEFT JOIN tokens t ON t.customer_id=c.id
      WHERE c.name LIKE ? OR c.phone LIKE ?
      GROUP BY c.id ORDER BY due DESC, c.name COLLATE NOCASE''', [s, s]);
  }

  Future<double> customerDue(int id) async {
    final db = await database;
    final r = await db.rawQuery('''SELECT COALESCE(SUM(total-paid),0) AS d FROM tokens
      WHERE customer_id=? AND status!='Cancelled' ''', [id]);
    return dbl(r.first['d']);
  }

  Future<void> receiveCustomerPayment(int customerId, double amount) async {
    final db = await database;
    await db.transaction((txn) async {
      final rows = await txn.query('tokens',
          where: "customer_id=? AND status!='Cancelled' AND total-paid>0.009",
          whereArgs: [customerId], orderBy: 'id');
      final due = rows.fold<double>(0, (s, r) => s + dbl(r['total']) - dbl(r['paid']));
      if (amount <= 0 || amount > due + 0.009) throw Exception('invalid amount');
      var left = amount;
      for (final r in rows) {
        if (left <= 0.0001) break;
        final bal = dbl(r['total']) - dbl(r['paid']);
        final part = left < bal ? left : bal;
        await txn.insert('payments', {
          'token_id': r['id'], 'amount': part,
          'payment_date': DateTime.now().toIso8601String(), 'method': 'Cash'});
        await txn.rawUpdate('UPDATE tokens SET paid=paid+? WHERE id=?', [part, r['id']]);
        left -= part;
      }
    });
  }

  Future<void> addExpense(String desc, double amount, DateTime date) async {
    final db = await database;
    await db.insert('expenses', {
      'expense_date': dayKey(date), 'description': desc, 'amount': amount});
  }

  Future<void> deleteExpense(int id) async {
    final db = await database;
    await db.delete('expenses', where: 'id=?', whereArgs: [id]);
  }

  Future<List<Rec>> expenses(String from, String to) async {
    final db = await database;
    return db.query('expenses', where: 'expense_date BETWEEN ? AND ?',
        whereArgs: [from, to], orderBy: 'expense_date DESC, id DESC');
  }

  Future<Map<String, double>> report(String from, String to) async {
    final db = await database;
    Future<Rec> one(String sql, List<Object?> a) async => (await db.rawQuery(sql, a)).first;
    final g = await one('''SELECT COUNT(*) c, COALESCE(SUM(wheat_kg),0) gross,
      COALESCE(SUM(deduction_kg),0) ded, COALESCE(SUM(net_wheat_kg),0) net,
      COALESCE(SUM(total),0) amt FROM tokens WHERE business_type='Grinding'
      AND status!='Cancelled' AND substr(created_at,1,10) BETWEEN ? AND ?''', [from, to]);
    final s = await one('''SELECT COUNT(*) c, COALESCE(SUM(total),0) amt FROM tokens
      WHERE business_type='Sale' AND status!='Cancelled'
      AND substr(created_at,1,10) BETWEEN ? AND ?''', [from, to]);
    final o = await one('''SELECT COALESCE(SUM(total-paid),0) v FROM tokens
      WHERE status!='Cancelled' AND substr(created_at,1,10) BETWEEN ? AND ?''', [from, to]);
    final rc = await one('''SELECT COALESCE(SUM(amount),0) v FROM payments
      WHERE substr(payment_date,1,10) BETWEEN ? AND ?''', [from, to]);
    final ex = await one('''SELECT COALESCE(SUM(amount),0) v FROM expenses
      WHERE expense_date BETWEEN ? AND ?''', [from, to]);
    final pend = await one('''SELECT COUNT(*) v FROM tokens
      WHERE business_type='Grinding' AND status='Pending' ''', []);
    final out = await one('''SELECT COALESCE(SUM(total-paid),0) v FROM tokens
      WHERE status!='Cancelled' ''', []);
    return {
      'gCount': dbl(g['c']), 'gross': dbl(g['gross']), 'ded': dbl(g['ded']),
      'net': dbl(g['net']), 'gAmt': dbl(g['amt']),
      'sCount': dbl(s['c']), 'sAmt': dbl(s['amt']),
      'billed': dbl(g['amt']) + dbl(s['amt']), 'rangeDue': dbl(o['v']),
      'received': dbl(rc['v']), 'expenses': dbl(ex['v']),
      'pending': dbl(pend['v']), 'outstanding': dbl(out['v']),
    };
  }

  Future<File> backupFile() async {
    final db = await database;
    try { await db.rawQuery('PRAGMA wal_checkpoint(FULL)'); } catch (_) {}
    final dir = await getTemporaryDirectory();
    final name = 'atta_chakki_backup_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.db';
    return File(await dbPath()).copy(p.join(dir.path, name));
  }

  Future<void> restore(String src) async {
    final f = File(src);
    final head = await f.openRead(0, 16).first;
    if (String.fromCharCodes(head) != 'SQLite format 3\u0000') {
      throw Exception('invalid backup file');
    }
    final test = await openDatabase(src, readOnly: true);
    try {
      await test.rawQuery('SELECT COUNT(*) FROM tokens');
      await test.rawQuery('SELECT COUNT(*) FROM settings');
      await test.rawQuery('SELECT COUNT(*) FROM payments');
    } finally {
      await test.close();
    }
    final path = await dbPath();
    await _db?.close();
    _db = null;
    final cur = File(path);
    if (await cur.exists()) await cur.copy('$path.before_restore');
    for (final s in ['-wal', '-shm', '-journal']) {
      final x = File('$path$s');
      if (await x.exists()) await x.delete();
    }
    await f.copy(path);
    await database;
  }
}
