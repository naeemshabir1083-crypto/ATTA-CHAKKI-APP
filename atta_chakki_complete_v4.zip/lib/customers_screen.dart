import 'package:flutter/material.dart';
import 'common.dart';
import 'db.dart';
import 'history_screen.dart';

class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});
  @override
  State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  final search = TextEditingController();
  List<Rec> rows = [];
  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { search.dispose(); super.dispose(); }
  Future<void> load() async {
    rows = await AppDb.instance.customersWithBalance(search: search.text);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final totalDue = rows.fold<double>(0, (s, r) => s + dbl(r['due']));
    return Scaffold(
      appBar: AppBar(title: const Text('گاہک اور بقایا')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: TextField(
          controller: search, onChanged: (_) => load(),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search),
              labelText: 'نام یا موبائل', border: OutlineInputBorder()),
        )),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: statRow('کل بقایا', '${money.format(totalDue)} روپے', bold: true,
              color: totalDue > 0 ? Colors.red.shade700 : null),
        ),
        Expanded(child: rows.isEmpty
            ? const Center(child: Text('کوئی گاہک نہیں'))
            : ListView.builder(
                itemCount: rows.length,
                itemBuilder: (_, i) {
                  final r = rows[i];
                  final due = dbl(r['due']);
                  return Card(child: ListTile(
                    leading: const Icon(Icons.person),
                    title: Text('${r['name']}'),
                    subtitle: Text('${r['phone']}'.isEmpty ? '${r['cnt']} ٹوکن' : '${r['phone']} • ${r['cnt']} ٹوکن'),
                    trailing: Text('${money.format(due)}',
                        style: TextStyle(fontWeight: FontWeight.bold,
                            color: due > 0.009 ? Colors.red.shade700 : Colors.green.shade800)),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(
                          builder: (_) => CustomerDetailScreen(id: r['id'] as int, name: '${r['name']}')));
                      load();
                    },
                  ));
                })),
      ]),
    );
  }
}

class CustomerDetailScreen extends StatefulWidget {
  final int id;
  final String name;
  const CustomerDetailScreen({super.key, required this.id, required this.name});
  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen> {
  double due = 0;
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    due = await AppDb.instance.customerDue(widget.id);
    if (mounted) setState(() {});
  }

  Future<void> receive() async {
    final v = await askAmount(context, 'بقایا وصول کریں', due);
    if (v == null) return;
    try {
      await AppDb.instance.receiveCustomerPayment(widget.id, v);
      await load();
      if (mounted) snack(context, 'رقم وصول ہو گئی (پرانے ٹوکن پہلے کلیئر ہوئے)');
    } catch (_) {
      if (mounted) snack(context, 'رقم درست نہیں');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.name)),
    body: Column(children: [
      Card(margin: const EdgeInsets.all(12), child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          statRow('کل بقایا', '${money.format(due)} روپے', bold: true,
              color: due > 0.009 ? Colors.red.shade700 : Colors.green.shade800),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: due > 0.009 ? receive : null,
            icon: const Icon(Icons.payments),
            label: const Text('بقایا وصول کریں'),
          ),
        ]),
      )),
      Expanded(child: HistoryScreen(customerId: widget.id, title: widget.name, embedded: true)),
    ]),
  );
}
