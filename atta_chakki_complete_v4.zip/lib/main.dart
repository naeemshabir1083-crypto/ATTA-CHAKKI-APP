import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'common.dart';
import 'customers_screen.dart';
import 'db.dart';
import 'delivery_screens.dart';
import 'expenses_screen.dart';
import 'history_screen.dart';
import 'reports_screen.dart';
import 'settings_screen.dart';
import 'token_screens.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.database;
  runApp(const AttaChakkiApp());
}

class AttaChakkiApp extends StatelessWidget {
  const AttaChakkiApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'آٹا چکی',
    debugShowCheckedModeBanner: false,
    locale: const Locale('ur'),
    supportedLocales: const [Locale('ur'), Locale('en')],
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff236b50)),
      useMaterial3: true,
      fontFamily: 'UrduFont',
    ),
    builder: (context, child) => Directionality(
      textDirection: TextDirection.rtl,
      child: child ?? const SizedBox.shrink(),
    ),
    home: const HomeScreen(),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, double> d = {};
  String shop = 'آٹا چکی';

  @override
  void initState() { super.initState(); refresh(); }

  Future<void> refresh() async {
    final t = dayKey(DateTime.now());
    d = await AppDb.instance.report(t, t);
    final s = await AppDb.instance.settings();
    shop = '${s['shop_name']}';
    if (mounted) setState(() {});
  }

  Future<void> open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    await refresh();
  }

  Widget tile(String title, IconData icon, Widget page, {int badge = 0}) => Card(
    child: InkWell(
      onTap: () => open(page),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Badge(
            isLabelVisible: badge > 0,
            label: Text('$badge'),
            child: Icon(icon, size: 34, color: const Color(0xff236b50)),
          ),
          const SizedBox(height: 8),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
        ]),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(shop)),
      body: RefreshIndicator(
        onRefresh: refresh,
        child: ListView(padding: const EdgeInsets.all(12), children: [
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('آج کا حساب', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const Divider(),
              statRow('ٹوکن / رسیدیں', '${((d['gCount'] ?? 0) + (d['sCount'] ?? 0)).toInt()}'),
              statRow('کل بل', '${money.format(d['billed'] ?? 0)} روپے'),
              statRow('آج وصول', '${money.format(d['received'] ?? 0)} روپے'),
              statRow('آج کے بلوں کا بقایا', '${money.format(d['rangeDue'] ?? 0)} روپے'),
              statRow('کل بقایا (تمام گاہک)', '${money.format(d['outstanding'] ?? 0)} روپے',
                  bold: true, color: (d['outstanding'] ?? 0) > 0 ? Colors.red.shade700 : null),
            ],
          ))),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.35,
            children: [
              tile('نیا ٹوکن / پسائی', Icons.confirmation_number, const NewTokenScreen()),
              tile('آٹا حوالگی', Icons.shopping_bag, const DeliveryListScreen(),
                  badge: (d['pending'] ?? 0).toInt()),
              tile('آٹا / گندم فروخت', Icons.sell, const NewSaleScreen()),
              tile('ٹوکن ہسٹری', Icons.receipt_long, const HistoryScreen()),
              tile('گاہک اور بقایا', Icons.people, const CustomersScreen()),
              tile('اخراجات', Icons.money_off, const ExpensesScreen()),
              tile('رپورٹس', Icons.bar_chart, const ReportsScreen()),
              tile('سیٹنگ اور بیک اپ', Icons.settings, const SettingsScreen()),
            ],
          ),
        ]),
      ),
    );
  }
}
