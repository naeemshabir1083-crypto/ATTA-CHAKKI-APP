import 'package:flutter/material.dart';
import 'common.dart';
import 'db.dart';
import 'receipt_screen.dart';

class HistoryScreen extends StatefulWidget {
  final int? customerId;
  final String title;
  final bool embedded;
  const HistoryScreen({super.key, this.customerId, this.title = 'ٹوکن ہسٹری', this.embedded = false});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final search = TextEditingController();
  List<Rec> rows = [];
  String filter = 'all';
  static const filters = {
    'all': 'سب', 'pending': 'زیر التوا', 'delivered': 'حوالگی مکمل',
    'unpaid': 'بقایا والے', 'cancelled': 'منسوخ',
  };

  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { search.dispose(); super.dispose(); }

  Future<void> load() async {
    rows = await AppDb.instance.tokens(
        search: search.text, filter: filter, customerId: widget.customerId);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: widget.embedded ? null : AppBar(title: Text(widget.title)),
    body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 4), child: TextField(
        controller: search, onChanged: (_) => load(),
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search),
            labelText: 'ٹوکن، نام یا موبائل تلاش کریں', border: OutlineInputBorder()),
      )),
      SizedBox(height: 48, child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: filters.entries.map((e) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
          child: ChoiceChip(
            label: Text(e.value), selected: filter == e.key,
            onSelected: (_) { filter = e.key; load(); },
          ),
        )).toList(),
      )),
      Expanded(child: rows.isEmpty
          ? const Center(child: Text('کوئی ریکارڈ موجود نہیں'))
          : ListView.builder(
              itemCount: rows.length,
              itemBuilder: (_, i) {
                final r = rows[i];
                final cancelled = r['status'] == 'Cancelled';
                final bal = cancelled ? 0.0 : dbl(r['total']) - dbl(r['paid']);
                final sale = r['business_type'] == 'Sale';
                return Card(child: ListTile(
                  title: Text('${sale ? 'فروخت' : 'ٹوکن'} #${r['token_no']} — ${r['customer_name']}'),
                  subtitle: Text('${money.format(dbl(r['total']))} روپے • بقایا ${money.format(bal)}\n${fmtDate(r['created_at'])}'),
                  isThreeLine: true,
                  trailing: Text(statusUrdu('${r['status']}'),
                      style: TextStyle(color: statusColor('${r['status']}'), fontWeight: FontWeight.bold)),
                  onTap: () async {
                    await Navigator.push(context, MaterialPageRoute(
                        builder: (_) => ReceiptScreen(id: r['id'] as int)));
                    load();
                  },
                ));
              })),
    ]),
  );
}
