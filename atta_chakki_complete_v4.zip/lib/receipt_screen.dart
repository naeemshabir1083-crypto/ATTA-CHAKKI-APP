import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_printer/flutter_bluetooth_printer.dart';
import 'common.dart';
import 'db.dart';
import 'delivery_screens.dart';

class ReceiptScreen extends StatefulWidget {
  final int id;
  const ReceiptScreen({super.key, required this.id});
  @override
  State<ReceiptScreen> createState() => _ReceiptScreenState();
}

class _ReceiptScreenState extends State<ReceiptScreen> {
  ReceiptController? controller;
  Rec? r;
  Rec? settings;
  List<Rec> pays = [];
  List<Rec> items = [];
  bool busy = false;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    final rec = await AppDb.instance.tokenById(widget.id);
    final s = await AppDb.instance.settings();
    final p = await AppDb.instance.payments(widget.id);
    final it = await AppDb.instance.itemsOf(widget.id);
    if (mounted) setState(() { r = rec; settings = s; pays = p; items = it; });
  }

  Future<void> printReceipt() async {
    if (controller == null) { snack(context, 'رسید ابھی تیار ہو رہی ہے'); return; }
    setState(() => busy = true);
    try {
      final device = await FlutterBluetoothPrinter.selectDevice(context);
      if (device == null) return;
      await controller!.print(address: device.address);
      if (mounted) snack(context, 'پرنٹ کی درخواست بھیج دی گئی');
    } catch (e) {
      if (mounted) snack(context, 'پرنٹر کی خرابی: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> receive(double bal) async {
    final v = await askAmount(context, 'رقم وصول کریں', bal);
    if (v == null) return;
    try {
      await AppDb.instance.addPayment(widget.id, v);
      await load();
      if (mounted) snack(context, 'رقم وصول ہو گئی');
    } catch (_) {
      if (mounted) snack(context, 'رقم درست نہیں');
    }
  }

  Future<void> cancel() async {
    final why = await askText(context, 'ٹوکن منسوخ کریں', 'منسوخی کی وجہ *');
    if (why == null) return;
    if (why.isEmpty) { if (mounted) snack(context, 'وجہ لکھنا ضروری ہے'); return; }
    if (!mounted) return;
    final ok = await confirm(context, 'تصدیق', 'یہ ٹوکن منسوخ ہو جائے گا اور وصول شدہ رقم واپس شمار ہو گی۔');
    if (!ok) return;
    await AppDb.instance.cancelToken(widget.id, why);
    await load();
  }

  Widget row(String a, String b, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Expanded(child: Text(a, textAlign: TextAlign.right,
          style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal))),
      const SizedBox(width: 8),
      Flexible(child: Text(b, textAlign: TextAlign.left,
          style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal))),
    ]),
  );

  Widget slip(Rec t) {
    final isSale = t['business_type'] == 'Sale';
    final cancelled = t['status'] == 'Cancelled';
    final total = dbl(t['total']);
    final paid = dbl(t['paid']);
    return Container(
      width: 280, color: Colors.white, padding: const EdgeInsets.all(12),
      child: DefaultTextStyle(
        style: const TextStyle(color: Colors.black, fontSize: 14, height: 1.6, fontFamily: 'UrduFont'),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('${settings?['shop_name'] ?? 'آٹا چکی'}',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          if ('${settings?['phone'] ?? ''}'.isNotEmpty) Text('${settings?['phone']}'),
          if ('${settings?['address'] ?? ''}'.isNotEmpty) Text('${settings?['address']}'),
          Text(isSale ? 'فروخت کی رسید' : 'پسائی ٹوکن',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          if (cancelled) const Text('*** منسوخ ***', style: TextStyle(fontWeight: FontWeight.bold)),
          const Divider(color: Colors.black),
          row(isSale ? 'رسید نمبر' : 'ٹوکن نمبر', '${t['token_no']}', bold: true),
          row('تاریخ', fmtDate(t['created_at'])),
          row('گاہک', '${t['customer_name']}'),
          if ('${t['phone']}'.isNotEmpty) row('موبائل', '${t['phone']}'),
          if (isSale) ...[
            row('آئٹم', '${t['product_name']}'),
            row('مقدار', '${t['sale_qty']}'),
            row('فی یونٹ ریٹ', money.format(dbl(t['rate']))),
          ] else ...[
            for (final x in items) ...[
              const Divider(color: Colors.black),
              Text('${x['grain_name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              row('اصل وزن', '${money.format(dbl(x['gross_kg']))} کلو'),
              if (dbl(x['deduction_kg']) > 0) row('کٹوتی', '${money.format(dbl(x['deduction_kg']))} کلو'),
              if ('${x['deduction_details']}'.isNotEmpty) row('کٹوتی وجہ', '${x['deduction_details']}'),
              row('خالص وزن', '${money.format(dbl(x['net_kg']))} کلو', bold: true),
              row('ریٹ', '${rateText(dbl(x['rate']))} ${methodUrdu(x['method'])}'),
              row('رقم', '${money.format(dbl(x['charges']))} روپے'),
              if (t['status'] == 'Delivered') row('واپس آٹا', '${money.format(dbl(x['flour_kg']))} کلو', bold: true),
            ],
            if (items.length > 1) row('کل خالص وزن', '${money.format(dbl(t['net_wheat_kg']))} کلو', bold: true),
            if (t['status'] == 'Delivered') row('حوالگی', fmtDate(t['delivered_at'])),
          ],
          const Divider(color: Colors.black),
          row('کل رقم', '${money.format(total)} روپے', bold: true),
          row('وصول شدہ', '${money.format(paid)} روپے'),
          row('بقایا', '${money.format(cancelled ? 0 : total - paid)} روپے', bold: true),
          if (cancelled && '${t['cancel_reason']}'.isNotEmpty) row('وجہ', '${t['cancel_reason']}'),
          const Divider(color: Colors.black),
          const Text('رسید محفوظ رکھیں، شکریہ'),
          const SizedBox(height: 12),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = r;
    if (t == null) {
      return Scaffold(appBar: AppBar(title: const Text('رسید')),
          body: const Center(child: CircularProgressIndicator()));
    }
    final cancelled = t['status'] == 'Cancelled';
    final bal = dbl(t['total']) - dbl(t['paid']);
    final isGrind = t['business_type'] == 'Grinding';
    return Scaffold(
      appBar: AppBar(title: const Text('رسید کا پری ویو')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Center(child: Container(
          color: Colors.white, padding: const EdgeInsets.all(8),
          child: Receipt(
            builder: (_) => slip(t),
            onInitialized: (c) { if (controller == null && mounted) setState(() => controller = c); },
          ),
        )),
        const SizedBox(height: 12),
        Center(child: Chip(
          label: Text(statusUrdu('${t['status']}')),
          labelStyle: TextStyle(color: statusColor('${t['status']}'), fontWeight: FontWeight.bold),
        )),
        FilledButton.icon(
          onPressed: busy ? null : printReceipt,
          icon: const Icon(Icons.print),
          label: Text(busy ? 'پرنٹ ہو رہا ہے...' : 'Bluetooth پر پرنٹ کریں'),
        ),
        const SizedBox(height: 8),
        if (isGrind && t['status'] == 'Pending')
          FilledButton.tonalIcon(
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => DeliverScreen(id: widget.id)));
              load();
            },
            icon: const Icon(Icons.shopping_bag),
            label: const Text('آٹا حوالگی'),
          ),
        if (!cancelled && bal > 0.009)
          FilledButton.tonalIcon(
            onPressed: () => receive(bal),
            icon: const Icon(Icons.payments),
            label: Text('بقایا وصول کریں (${money.format(bal)})'),
          ),
        if (!cancelled)
          TextButton.icon(
            onPressed: cancel,
            icon: Icon(Icons.cancel, color: Colors.red.shade700),
            label: Text('ٹوکن منسوخ کریں', style: TextStyle(color: Colors.red.shade700)),
          ),
        if (pays.isNotEmpty) ...[
          const SizedBox(height: 8),
          Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('ادائیگیوں کی تفصیل', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              for (final p in pays)
                statRow('${fmtDate(p['payment_date'])}${p['method'] == 'Refund' ? ' (واپسی)' : ''}',
                    '${money.format(dbl(p['amount']))} روپے'),
            ],
          ))),
        ],
      ]),
    );
  }
}
