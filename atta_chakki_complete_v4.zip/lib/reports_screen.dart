import 'package:flutter/material.dart';
import 'common.dart';
import 'db.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  late DateTime from;
  late DateTime to;
  Map<String, double> d = {};
  List<Rec> byGrain = [];

  @override
  void initState() {
    super.initState();
    final n = DateTime.now();
    from = DateTime(n.year, n.month, n.day);
    to = from;
    load();
  }

  Future<void> load() async {
    d = await AppDb.instance.report(dayKey(from), dayKey(to));
    byGrain = await AppDb.instance.grainReport(dayKey(from), dayKey(to));
    if (mounted) setState(() {});
  }

  void setRange(DateTime a, DateTime b) { from = a; to = b; load(); }

  Future<void> pick() async {
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020), lastDate: DateTime.now().add(const Duration(days: 1)),
      initialDateRange: DateTimeRange(start: from, end: to),
    );
    if (r != null) setRange(r.start, r.end);
  }

  Widget box(String title, List<Widget> kids) => Card(child: Padding(
    padding: const EdgeInsets.all(14),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      const Divider(),
      ...kids,
    ]),
  ));

  String m(String k) => '${money.format(d[k] ?? 0)} روپے';
  String kgs(String k) => '${money.format(d[k] ?? 0)} کلو';
  String cnt(String k) => '${(d[k] ?? 0).toInt()}';

  @override
  Widget build(BuildContext context) {
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final cash = (d['received'] ?? 0) - (d['expenses'] ?? 0);
    return Scaffold(
      appBar: AppBar(title: const Text('رپورٹس')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Wrap(spacing: 8, children: [
          ActionChip(label: const Text('آج'), onPressed: () => setRange(today, today)),
          ActionChip(label: const Text('کل'), onPressed: () {
            final y = today.subtract(const Duration(days: 1));
            setRange(y, y);
          }),
          ActionChip(label: const Text('اس مہینے'),
              onPressed: () => setRange(DateTime(n.year, n.month, 1), today)),
          ActionChip(label: const Text('تاریخ منتخب کریں'), onPressed: pick),
        ]),
        const SizedBox(height: 8),
        Center(child: Text(
          from == to ? dayFmt.format(from) : '${dayFmt.format(from)}  تا  ${dayFmt.format(to)}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        )),
        const SizedBox(height: 8),
        box('پسائی', [
          statRow('ٹوکن', cnt('gCount')),
          statRow('کل اصل وزن', kgs('gross')),
          statRow('کٹوتی', kgs('ded')),
          statRow('کل خالص وزن', kgs('net'), bold: true),
          statRow('پسائی کی رقم', m('gAmt'), bold: true),
        ]),
        box('اناج کے حساب سے', [
          if (byGrain.isEmpty) const Text('کوئی ریکارڈ نہیں'),
          for (final g in byGrain) ...[
            Text('${g['name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
            statRow('اصل وزن', '${money.format(dbl(g['gross']))} کلو'),
            statRow('خالص وزن', '${money.format(dbl(g['net']))} کلو'),
            statRow('رقم', '${money.format(dbl(g['amt']))} روپے', bold: true),
            const Divider(),
          ],
        ]),
        box('فروخت', [
          statRow('رسیدیں', cnt('sCount')),
          statRow('فروخت کی رقم', m('sAmt'), bold: true),
        ]),
        box('حساب', [
          statRow('کل بل (پسائی + فروخت)', m('billed')),
          statRow('اس مدت کے بلوں کا بقایا', m('rangeDue')),
          statRow('وصولی (نقد)', m('received')),
          statRow('اخراجات', m('expenses')),
          const Divider(),
          statRow('خالص نقد', '${money.format(cash)} روپے', bold: true,
              color: cash < 0 ? Colors.red.shade700 : Colors.green.shade800),
        ]),
        box('موجودہ صورتحال (تمام وقت)', [
          statRow('زیر التوا ٹوکن (آٹا باقی)', cnt('pending')),
          statRow('کل بقایا گاہکوں سے', m('outstanding'), bold: true),
        ]),
      ]),
    );
  }
}
