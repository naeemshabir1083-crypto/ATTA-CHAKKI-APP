# آٹا چکی - Atta Chakki App (v2)

Offline Urdu Android app (Flutter + SQLite) for flour mills.

## Features
- Grinding token with multiple grain lines (wheat, maize, rice, chana, bajra...), each with its own deduction (kg or %) + reason, net weight and rate (per kg / per maund); advance payment
- Grains master list with default rates (Settings > اناج اور ریٹ)
- Delivery (pickup): pending tokens list, returned flour kg per grain, collect balance, udhaar allowed with confirmation
- Flour/wheat sale receipts (cash or udhaar), separate numbering from grinding tokens
- Customers: auto-saved, name/phone autocomplete, per-customer balance, receive payment (oldest tokens cleared first)
- Receipt: 58mm Bluetooth print, payment history, re-print any time
- Cancel token with reason (payments refunded in cash book)
- Expenses (bijli, labour, repair...)
- Reports: today / yesterday / month / custom range - per-grain breakdown, gross/net kg, charges, sales, received, expenses, net cash, outstanding
- Backup (share .db file) and restore
- Bundled Urdu font (Noto Naskh Arabic)

## Build APK
Push to GitHub > Actions > "Build APK" > Run workflow > download `AttaChakki-APK`.
Or locally: `flutter create . --platforms=android` (keep lib/ and pubspec.yaml), add Bluetooth permissions to AndroidManifest, then `flutter pub get && flutter build apk --release`.

## Notes
- Uninstall any older build first (database schema changed).
- Test printing on your exact 58mm printer.
- Not included: wheat purchase/stock ledger, multi-device sync, user login/PIN.
